fx_version 'cerulean'
game 'gta5'
lua54 'yes'
description 'qb-hud'
version '2.2.0'

server_script 'server.lua'


